"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function PriceList() {
  const [category, setCategory] = useState("viso")

  const priceData = {
    viso: [
      { name: "Pulizia Viso Profonda", duration: "60 min", price: "€60" },
      { name: "Trattamento Anti-Age", duration: "75 min", price: "€85" },
      { name: "Maschera Idratante", duration: "45 min", price: "€45" },
      { name: "Trattamento Acne", duration: "60 min", price: "€65" },
      { name: "Peeling Viso", duration: "30 min", price: "€50" },
      { name: "Radiofrequenza Viso", duration: "45 min", price: "€70" },
    ],
    corpo: [
      { name: "Scrub Corpo", duration: "45 min", price: "€70" },
      { name: "Trattamento Anticellulite", duration: "60 min", price: "€90" },
      { name: "Fanghi Drenanti", duration: "60 min", price: "€75" },
      { name: "Massaggio Modellante", duration: "50 min", price: "€80" },
      { name: "Pressoterapia", duration: "30 min", price: "€40" },
      { name: "Radiofrequenza Corpo", duration: "45 min", price: "€80" },
    ],
    mani: [
      { name: "Manicure Base", duration: "30 min", price: "€25" },
      { name: "Manicure con Semipermanente", duration: "45 min", price: "€35" },
      { name: "Ricostruzione Unghie", duration: "90 min", price: "€60" },
      { name: "Pedicure Estetico", duration: "45 min", price: "€35" },
      { name: "Pedicure Curativo", duration: "60 min", price: "€45" },
      { name: "Applicazione Smalto", duration: "15 min", price: "€10" },
    ],
    depilazione: [
      { name: "Gamba Intera", duration: "45 min", price: "€35" },
      { name: "Mezza Gamba", duration: "30 min", price: "€20" },
      { name: "Inguine", duration: "20 min", price: "€15" },
      { name: "Ascelle", duration: "15 min", price: "€12" },
      { name: "Braccia", duration: "30 min", price: "€20" },
      { name: "Labbro Superiore", duration: "10 min", price: "€8" },
    ],
    massaggi: [
      { name: "Massaggio Rilassante", duration: "50 min", price: "€65" },
      { name: "Massaggio Decontratturante", duration: "50 min", price: "€70" },
      { name: "Massaggio Linfodrenante", duration: "60 min", price: "€75" },
      { name: "Hot Stone Massage", duration: "75 min", price: "€85" },
      { name: "Massaggio Sportivo", duration: "50 min", price: "€70" },
      { name: "Riflessologia Plantare", duration: "40 min", price: "€50" },
    ],
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-pink-100 overflow-hidden">
      <Tabs defaultValue="viso" onValueChange={setCategory}>
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full rounded-none">
          <TabsTrigger value="viso">Viso</TabsTrigger>
          <TabsTrigger value="corpo">Corpo</TabsTrigger>
          <TabsTrigger value="mani">Mani/Piedi</TabsTrigger>
          <TabsTrigger value="depilazione">Depilazione</TabsTrigger>
          <TabsTrigger value="massaggi">Massaggi</TabsTrigger>
        </TabsList>
        {Object.keys(priceData).map((key) => (
          <TabsContent key={key} value={key} className="m-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50%]">Trattamento</TableHead>
                  <TableHead>Durata</TableHead>
                  <TableHead className="text-right">Prezzo</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {priceData[key as keyof typeof priceData].map((item, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.duration}</TableCell>
                    <TableCell className="text-right font-medium text-pink-600">{item.price}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
