import Link from "next/link"
import Image from "next/image"
import { ChevronRight, MapPin, Phone, Mail, Clock, Instagram, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Testimonials } from "@/components/testimonials"
import { BookingForm } from "@/components/booking-form"
import { PriceList } from "@/components/price-list"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl font-semibold text-pink-600">Bella Estetica</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="#chi-siamo" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Chi Siamo
            </Link>
            <Link href="#trattamenti" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Trattamenti
            </Link>
            <Link href="#listino" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Listino Prezzi
            </Link>
            <Link href="#prenotazioni" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Prenotazioni
            </Link>
            <Link href="#recensioni" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Recensioni
            </Link>
            <Link href="#contatti" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Contatti
            </Link>
          </nav>
          <Button className="hidden md:inline-flex bg-pink-600 hover:bg-pink-700">Prenota Ora</Button>
          <Button variant="ghost" size="icon" className="md:hidden">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-pink-50/90 to-white/80 z-10" />
          <div className="relative h-[70vh] w-full">
            <Image
              src="/placeholder.svg?height=1080&width=1920"
              alt="Centro Estetico"
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="container absolute inset-0 z-20 flex flex-col items-start justify-center gap-4">
            <div className="max-w-xl space-y-4">
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl text-pink-800">
                Bella Estetica
              </h1>
              <p className="text-xl md:text-2xl font-light text-pink-950/80 italic">
                La tua bellezza, il nostro impegno
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button className="bg-pink-600 hover:bg-pink-700 text-white" size="lg">
                  Prenota Ora
                </Button>
                <Button variant="outline" size="lg" className="border-pink-200 hover:bg-pink-50">
                  Scopri i Trattamenti
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Chi Siamo */}
        <section id="chi-siamo" className="py-16 bg-gradient-to-b from-white to-pink-50">
          <div className="container">
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="md:w-1/2 space-y-6">
                <h2 className="text-3xl font-bold tracking-tight text-pink-800">Chi Siamo</h2>
                <p className="text-lg text-gray-700">
                  Da oltre 15 anni, Bella Estetica è sinonimo di eccellenza nel settore della bellezza e del benessere.
                  Il nostro centro nasce dalla passione per l'estetica e dalla volontà di offrire trattamenti
                  personalizzati di alta qualità in un ambiente rilassante e accogliente.
                </p>
                <p className="text-lg text-gray-700">
                  La nostra filosofia si basa sul concetto di bellezza naturale: valorizziamo la bellezza unica di ogni
                  persona, rispettando la sua individualità e le sue esigenze specifiche.
                </p>
                <div className="flex gap-4 pt-4">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-pink-600">15+</p>
                    <p className="text-sm text-gray-600">Anni di esperienza</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-pink-600">5000+</p>
                    <p className="text-sm text-gray-600">Clienti soddisfatti</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-pink-600">20+</p>
                    <p className="text-sm text-gray-600">Trattamenti esclusivi</p>
                  </div>
                </div>
              </div>
              <div className="md:w-1/2 grid grid-cols-2 gap-4">
                <div className="relative h-64 overflow-hidden rounded-lg shadow-md">
                  <Image
                    src="/placeholder.svg?height=600&width=400"
                    alt="Il nostro team"
                    fill
                    className="object-cover transition-transform hover:scale-105 duration-300"
                  />
                </div>
                <div className="relative h-64 overflow-hidden rounded-lg shadow-md">
                  <Image
                    src="/placeholder.svg?height=600&width=400"
                    alt="Il nostro centro"
                    fill
                    className="object-cover transition-transform hover:scale-105 duration-300"
                  />
                </div>
                <div className="relative h-64 overflow-hidden rounded-lg shadow-md">
                  <Image
                    src="/placeholder.svg?height=600&width=400"
                    alt="I nostri prodotti"
                    fill
                    className="object-cover transition-transform hover:scale-105 duration-300"
                  />
                </div>
                <div className="relative h-64 overflow-hidden rounded-lg shadow-md">
                  <Image
                    src="/placeholder.svg?height=600&width=400"
                    alt="I nostri trattamenti"
                    fill
                    className="object-cover transition-transform hover:scale-105 duration-300"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Trattamenti */}
        <section id="trattamenti" className="py-16 bg-white">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight text-pink-800 text-center mb-12">I Nostri Trattamenti</h2>
            <Tabs defaultValue="viso" className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-6 mb-8">
                <TabsTrigger value="viso">Viso</TabsTrigger>
                <TabsTrigger value="corpo">Corpo</TabsTrigger>
                <TabsTrigger value="mani">Mani/Piedi</TabsTrigger>
                <TabsTrigger value="depilazione">Depilazione</TabsTrigger>
                <TabsTrigger value="massaggi">Massaggi</TabsTrigger>
                <TabsTrigger value="speciali">Speciali</TabsTrigger>
              </TabsList>
              <TabsContent value="viso" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    {
                      title: "Pulizia Viso Profonda",
                      description: "Trattamento di pulizia profonda per rimuovere impurità e punti neri",
                      price: "€60",
                      image: "/placeholder.svg?height=300&width=400",
                    },
                    {
                      title: "Trattamento Anti-Age",
                      description: "Trattamento intensivo per contrastare i segni dell'invecchiamento",
                      price: "€85",
                      image: "/placeholder.svg?height=300&width=400",
                    },
                    {
                      title: "Maschera Idratante",
                      description: "Maschera nutriente per pelli secche e disidratate",
                      price: "€45",
                      image: "/placeholder.svg?height=300&width=400",
                    },
                  ].map((treatment, index) => (
                    <Card key={index} className="overflow-hidden transition-all hover:shadow-lg">
                      <div className="relative h-48">
                        <Image
                          src={treatment.image || "/placeholder.svg"}
                          alt={treatment.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-lg font-semibold">{treatment.title}</h3>
                          <span className="text-pink-600 font-medium">{treatment.price}</span>
                        </div>
                        <p className="text-gray-600">{treatment.description}</p>
                        <Button variant="link" className="p-0 mt-4 text-pink-600">
                          Scopri di più
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="corpo" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    {
                      title: "Scrub Corpo",
                      description: "Esfoliazione completa per una pelle morbida e rinnovata",
                      price: "€70",
                      image: "/placeholder.svg?height=300&width=400",
                    },
                    {
                      title: "Trattamento Anticellulite",
                      description: "Trattamento mirato per contrastare la cellulite",
                      price: "€90",
                      image: "/placeholder.svg?height=300&width=400",
                    },
                    {
                      title: "Fanghi Drenanti",
                      description: "Trattamento con fanghi per drenare e sgonfiare",
                      price: "€75",
                      image: "/placeholder.svg?height=300&width=400",
                    },
                  ].map((treatment, index) => (
                    <Card key={index} className="overflow-hidden transition-all hover:shadow-lg">
                      <div className="relative h-48">
                        <Image
                          src={treatment.image || "/placeholder.svg"}
                          alt={treatment.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-lg font-semibold">{treatment.title}</h3>
                          <span className="text-pink-600 font-medium">{treatment.price}</span>
                        </div>
                        <p className="text-gray-600">{treatment.description}</p>
                        <Button variant="link" className="p-0 mt-4 text-pink-600">
                          Scopri di più
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              {/* Altri TabsContent per le altre categorie di trattamenti */}
              <TabsContent value="mani" className="space-y-4">
                {/* Contenuto per mani/piedi */}
                <div className="text-center py-8">
                  <p className="text-gray-500">
                    Seleziona questa categoria per visualizzare i trattamenti per mani e piedi
                  </p>
                </div>
              </TabsContent>
              <TabsContent value="depilazione" className="space-y-4">
                {/* Contenuto per depilazione */}
                <div className="text-center py-8">
                  <p className="text-gray-500">
                    Seleziona questa categoria per visualizzare i trattamenti di depilazione
                  </p>
                </div>
              </TabsContent>
              <TabsContent value="massaggi" className="space-y-4">
                {/* Contenuto per massaggi */}
                <div className="text-center py-8">
                  <p className="text-gray-500">Seleziona questa categoria per visualizzare i massaggi disponibili</p>
                </div>
              </TabsContent>
              <TabsContent value="speciali" className="space-y-4">
                {/* Contenuto per trattamenti speciali */}
                <div className="text-center py-8">
                  <p className="text-gray-500">Seleziona questa categoria per visualizzare i trattamenti speciali</p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Listino Prezzi */}
        <section id="listino" className="py-16 bg-pink-50">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight text-pink-800 text-center mb-12">Listino Prezzi</h2>
            <PriceList />
          </div>
        </section>

        {/* Prenotazioni */}
        <section id="prenotazioni" className="py-16 bg-white">
          <div className="container">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold tracking-tight text-pink-800 text-center mb-4">
                Prenota il tuo Trattamento
              </h2>
              <p className="text-center text-gray-600 mb-8">
                Scegli la data e l'ora che preferisci e compila il modulo per prenotare il tuo trattamento. Riceverai
                una conferma via email.
              </p>
              <BookingForm />
            </div>
          </div>
        </section>

        {/* Recensioni */}
        <section id="recensioni" className="py-16 bg-gradient-to-b from-pink-50 to-white">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight text-pink-800 text-center mb-12">
              Cosa Dicono i Nostri Clienti
            </h2>
            <Testimonials />
          </div>
        </section>

        {/* Contatti */}
        <section id="contatti" className="py-16 bg-white">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight text-pink-800 text-center mb-12">Contatti</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="h-6 w-6 text-pink-600 mt-1" />
                  <div>
                    <h3 className="text-lg font-medium">Indirizzo</h3>
                    <p className="text-gray-600">Via Roma 123, 00100 Roma (RM)</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone className="h-6 w-6 text-pink-600 mt-1" />
                  <div>
                    <h3 className="text-lg font-medium">Telefono</h3>
                    <p className="text-gray-600">+39 06 1234567</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="h-6 w-6 text-pink-600 mt-1" />
                  <div>
                    <h3 className="text-lg font-medium">Email</h3>
                    <p className="text-gray-600">info@bellaestetica.it</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Clock className="h-6 w-6 text-pink-600 mt-1" />
                  <div>
                    <h3 className="text-lg font-medium">Orari di Apertura</h3>
                    <div className="text-gray-600 space-y-1">
                      <p>Lunedì - Venerdì: 9:00 - 19:00</p>
                      <p>Sabato: 9:00 - 17:00</p>
                      <p>Domenica: Chiuso</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-4 pt-4">
                  <Button variant="outline" size="icon" className="rounded-full border-pink-200 hover:bg-pink-50">
                    <Instagram className="h-5 w-5 text-pink-600" />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full border-pink-200 hover:bg-pink-50">
                    <MessageCircle className="h-5 w-5 text-pink-600" />
                  </Button>
                </div>
              </div>
              <div className="h-[400px] rounded-lg overflow-hidden shadow-md">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11880.492291371422!2d12.4922309!3d41.9027835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f6196f9928ebb%3A0xb90f770693656e38!2sRoma%20RM!5e0!3m2!1sit!2sit!4v1653669093619!5m2!1sit!2sit"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-pink-800 text-white py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Bella Estetica</h3>
              <p className="text-pink-100">
                La tua bellezza, il nostro impegno. Centro estetico professionale con trattamenti personalizzati.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Link Rapidi</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#chi-siamo" className="text-pink-100 hover:text-white transition-colors">
                    Chi Siamo
                  </Link>
                </li>
                <li>
                  <Link href="#trattamenti" className="text-pink-100 hover:text-white transition-colors">
                    Trattamenti
                  </Link>
                </li>
                <li>
                  <Link href="#listino" className="text-pink-100 hover:text-white transition-colors">
                    Listino Prezzi
                  </Link>
                </li>
                <li>
                  <Link href="#prenotazioni" className="text-pink-100 hover:text-white transition-colors">
                    Prenotazioni
                  </Link>
                </li>
                <li>
                  <Link href="#recensioni" className="text-pink-100 hover:text-white transition-colors">
                    Recensioni
                  </Link>
                </li>
                <li>
                  <Link href="#contatti" className="text-pink-100 hover:text-white transition-colors">
                    Contatti
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Trattamenti</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                    Trattamenti Viso
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                    Trattamenti Corpo
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                    Manicure e Pedicure
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                    Depilazione
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                    Massaggi
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contatti</h3>
              <address className="not-italic text-pink-100 space-y-2">
                <p>Via Roma 123, 00100 Roma (RM)</p>
                <p>+39 06 1234567</p>
                <p>info@bellaestetica.it</p>
              </address>
              <div className="flex gap-4 mt-4">
                <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                  <Instagram className="h-5 w-5" />
                </Link>
                <Link href="#" className="text-pink-100 hover:text-white transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </Link>
              </div>
            </div>
          </div>
          <div className="border-t border-pink-700 mt-8 pt-8 text-center text-pink-200 text-sm">
            <p>&copy; {new Date().getFullYear()} Bella Estetica. Tutti i diritti riservati.</p>
            <div className="mt-2 space-x-4">
              <Link href="#" className="hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="hover:text-white transition-colors">
                Cookie Policy
              </Link>
              <Link href="#" className="hover:text-white transition-colors">
                Termini e Condizioni
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
